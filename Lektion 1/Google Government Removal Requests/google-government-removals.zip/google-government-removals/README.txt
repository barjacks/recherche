google-government-removal-requests.csv

This file contains the information for all content removal requests displayed in
the Transparency Report, organized by country and biannual reporting period.


google-government-detailed-removal-requests.csv

This file contains the information for all content removal requests displayed in
the Transparency Report, organized by country, biannual reporting period,
product, and the alleged reason for removal. Consistent with the Report, we've
omitted cases where some countries did not issue enough requests for us to go
into detail. Since we began disclosing reasons for removal in the July–December
2010 reporting period, the reason data is missing for reporting periods earlier
than that time.


See https://transparencyreport.google.com/government-removals/overview for more
information.
